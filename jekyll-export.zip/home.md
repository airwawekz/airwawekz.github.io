---
id: 5
title: Home
date: 2018-10-13T10:43:48+00:00
author: admin
layout: page
guid: https://syzhack.com/blog/?page_id=5
---
root@~localhost: echo &#8216;Welcome to my blog! &#8216;