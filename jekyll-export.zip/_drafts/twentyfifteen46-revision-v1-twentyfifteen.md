---
id: 56
title: twentyfifteen
date: 2018-10-21T09:19:29+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2018/10/21/46-revision-v1/
permalink: /index.php/2018/10/21/46-revision-v1/
---
.hentry {  
background-color: rgba(355, 0, 0, 0.2);  
}

.site-info { display: none; }