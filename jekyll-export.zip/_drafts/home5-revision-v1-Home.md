---
id: 32
title: Home
date: 2018-10-14T17:26:22+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2018/10/14/5-revision-v1/
permalink: /index.php/2018/10/14/5-revision-v1/
---
root@~localhost: echo &#8216;Welcome to my blog! &#8216;