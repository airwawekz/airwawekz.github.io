---
id: 165
title: 'mail.yahoo.com – Stored Cross-Site Scripting – $2,000 awarded [sad story] x'
date: 2019-01-07T16:29:49+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2019/01/07/164-revision-v1/
permalink: /index.php/2019/01/07/164-revision-v1/
---
<img class="wp-image-161 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2019/01/yahoo-76684_1280-766x395.png" alt="" width="303" height="156" />

Hello guys, today I will share my sad Bug Bounty hunting story .

Everything started when I read some Bug  Bounty articles  of the Yahoo giant who inspired me to found this bug, among those articles were those of security researcher Jouko Pynnönen.

He found two Stored Cross-Site Scripting bugs in mail.yahoo.com sub-domain and he got for every bug $10,000, that happend in 2015 &#8211; 2016.

Full articles:

• https://klikki.fi/adv/yahoo.html

• https://klikki.fi/adv/yahoo2.html

* * *

&nbsp;

I found same vulnerability type in same sub-domain and I got $2,000, it&#8217;s that correct?! 🤔 I want to say that: I reported the bug when the Yahoo Bug Bounty action alone. At the moment  Yahoo made a partnership with Oath.

<img class="alignnone size-full wp-image-160" src="https://syzhack.com/blog/wp-content/uploads/2019/01/download.png" alt="" width="1355" height="228" /> 

Ok, let&#8217;s see my proof of concept video.

### #Vulnerability type:

Stored Cross-Site Scripting

### #Author:

Măgherușan Ovidiu Teodor  
—-

### #Proof of concept:



&nbsp;

### #Vendor response: {#a384.graf.graf--h3.graf-after--p}

Jul 10th, 2018 &#8211; Bug subbmited

&nbsp;

&nbsp;

&nbsp;