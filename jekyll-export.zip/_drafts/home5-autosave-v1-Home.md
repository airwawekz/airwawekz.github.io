---
id: 31
title: Home
date: 2018-10-14T17:25:43+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2018/10/14/5-autosave-v1/
permalink: /index.php/2018/10/14/5-autosave-v1/
---
root@~localhost: ehcoWelcome to my blog!