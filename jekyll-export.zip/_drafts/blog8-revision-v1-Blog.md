---
id: 14
title: Blog
date: 2018-10-13T10:43:48+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2018/10/13/8-revision-v1/
permalink: /index.php/2018/10/13/8-revision-v1/
---
