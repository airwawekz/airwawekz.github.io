---
id: 203
title: About
date: 2019-03-21T20:39:30+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2019/03/21/6-revision-v1/
permalink: /index.php/2019/03/21/6-revision-v1/
---
<img class="wp-image-144 alignleft" src="https://syzhack.com/blog/wp-content/uploads/2018/12/info.png" alt="" width="159" height="159" />

Hello guys,

My name is Măgherușan Ovidiu Teodor. I&#8217;m 22 years old, located in Romania, currently in Austria.

I&#8217;m independent Security Researcher with a huge interest in web, mobile and server-side security things. Sometimes I participate in bug bounty programs, especially platform based programs.

My learning sources are Google, hacking forums, Twitter, Youtube.

&#8220;You can use the Internet as a dangerous gun.&#8221;

&nbsp;

My skills:

• Security Consulting  
• Web Applications Security  
• Mobile Application Security  
• Server Application Security  
• Bug Bounty Hunting