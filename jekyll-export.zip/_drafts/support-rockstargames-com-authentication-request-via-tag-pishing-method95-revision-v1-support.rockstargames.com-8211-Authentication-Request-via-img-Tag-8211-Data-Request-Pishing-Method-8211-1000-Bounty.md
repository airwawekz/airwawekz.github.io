---
id: 104
title: 'support.rockstargames.com &#8211; Authentication Request via img Tag &#8211; Data Request (Pishing Method) &#8211; $1,000 Bounty'
date: 2018-12-08T14:35:39+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2018/12/08/95-revision-v1/
permalink: /index.php/2018/12/08/95-revision-v1/
---
<img class="wp-image-77 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Rockstar_Games_Logo.svg_.png" alt="" width="126" height="116" />

### #Vulnerability type:

Pishing via<img /> Tag

### #Author:

Măgherușan Ovidiu Teodor  
&#8212;-

### #Proof of concept:



<div class="aspectRatioPlaceholder is-locked">
</div>

<div>
</div>

### #Vendor response: {#a384.graf.graf--h3.graf-after--p}

<p id="634a" class="graf graf--p graf-after--h3">
  Rockstargames provides standardized rewards for most security bugs, as described on the page for it&#8217;s <a class="markup--anchor markup--p-anchor" href="https://hackerone.com/rockstargames?view_policy=true" target="_blank" rel="nofollow noopener" data-href="https://hackerone.com/rockstargames?view_policy=true">vulnerability reward program</a>. In our case, a proper XSS on the support.rockstargames.com domain will usually trigger a $1,000 bounty.
</p>

<p id="0fc4" class="graf graf--p graf-after--p">
  Dec 1st, 2017 — I fill in the <a class="markup--anchor markup--p-anchor" href="https://hackerone.com/rockstargames/reports/new" target="_blank" rel="nofollow noopener" data-href="https://hackerone.com/rockstargames/reports/new">report form</a>.
</p>

Oct 10th, 2017 — My report is triaged, already!

Oct 23rd, 2017 — First bounty awarded via Hackerone

<img class="alignnone size-full wp-image-97" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Screenshot_5.png" alt="" width="976" height="247" /> 

Nov, 9th 2017 — Additional bounty awarded

<img class="alignnone size-full wp-image-98" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Screenshot_6.png" alt="" width="981" height="275" /> 

Feb 15th, 2018 — Well, this is fixed.

### #Thanks Page:

https://hackerone.com/rockstargames/thanks