---
id: 305
title: nullpoint
date: 2020-02-10T17:15:28+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2020/02/10/268-revision-v1/
permalink: /index.php/2020/02/10/268-revision-v1/
fw_options:
  - 'a:0:{}'
---
.single .hentry {  
text-align: center;  
}  
.single .wp-post-image {  
display: inline-block;  
margin: auto;  
}