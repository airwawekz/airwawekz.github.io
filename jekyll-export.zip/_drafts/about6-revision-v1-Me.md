---
id: 284
title: Me
date: 2020-01-08T13:48:55+00:00
author: admin
layout: revision
guid: https://syzhack.com/blog/index.php/2020/01/08/6-revision-v1/
permalink: /index.php/2020/01/08/6-revision-v1/
fw_options:
  - 'a:0:{}'
---
<img class="wp-image-144 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/info.png" alt="" width="159" height="159" />

<p style="text-align: center;">
  Hello guys,
</p>

<p style="text-align: center;">
  My name is Măgherușan Ovidiu Teodor. I&#8217;m 22 years old, located in Romania, currently in Austria.
</p>

<p style="text-align: center;">
  I&#8217;m independent Security Researcher with a huge interest in web, mobile and server-side security things. Sometimes I participate in bug bounty programs, especially platform based programs.
</p>

<p style="text-align: center;">
  My learning sources are Google, hacking forums, Twitter, Youtube.
</p>

<p style="text-align: center;">
  <em>Quote: &#8220;You can use the Internet as a dangerous gun.&#8221;</em>
</p>

<h4 style="text-align: center;">
  My skills:
</h4>

<p style="text-align: center;">
  • Security Consulting<br /> • Web Applications Security<br /> • Mobile Application Security<br /> • Server Application Security<br /> • Bug Bounty Hunting
</p>