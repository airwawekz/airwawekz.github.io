---
id: 126
title: Targets
date: 2018-12-12T17:21:33+00:00
author: admin
layout: page
guid: https://syzhack.com/blog/?page_id=126
nullpoint_basic_post_layer_select:
  - 1-col
nullpoint_post_transparent_header:
  - 'no'
nullpoint_post_allow_breadcrumbs:
  - 'no'
nullpoint_top_padding:
  - ""
nullpoint_bottom_padding:
  - ""
---
<img class="wp-image-118 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/energy-memory-focus-target.png" alt="" width="106" height="107" />

&nbsp;

<p style="text-align: center;">
  • Google
</p>

<p style="text-align: center;">
  • PayPal
</p>

<p style="text-align: center;">
  • eBay
</p>

<p style="text-align: center;">
  • Yahoo
</p>

<p style="text-align: center;">
  • Redhat
</p>

<p style="text-align: center;">
  • Rockstargames
</p>

<p style="text-align: center;">
  • Snapchat
</p>

<p style="text-align: center;">
  • Mozilla
</p>

<p style="text-align: center;">
  • vBulletin
</p>

<p style="text-align: center;">
  • <em>I’ll continue</em><em>…</em>
</p>

&nbsp;