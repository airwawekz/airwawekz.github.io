---
id: 151
title: 'snappublisher.snapchat.com &#8211; Asset &#8211; Stored XSS &#8211; Status: &#8220;Informative&#8221;'
date: 2018-12-12T21:51:32+00:00
author: admin
layout: post
guid: https://syzhack.com/blog/?p=151
permalink: /index.php/2018/12/12/revino-la-editaresnappublisher-sc-cdn-net-stored-xss-status-informative/
nullpoint_basic_post_layer_select:
  - 1-col
nullpoint_post_allow_breadcrumbs:
  - 'no'
nullpoint_post_nav:
  - 'no'
categories:
  - bug bounty
---
<img class="wp-image-152 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/snapchat-logo-transparent-900x762.png" alt="" width="145" height="123" />

&nbsp;

### #Vulnerability type:

Stored Cross-Site Scripting

### #Author:

Măgherușan Ovidiu Teodor  
—-

### #Description:

In this video, I used an SVG image to execute javascript.

### #Proof of concept:



&nbsp;

### #Vendor response: {#a384.graf.graf--h3.graf-after--p}

Dec 11th, 2018 — Report submitted  
Dec 12th, 2018 — Closed as Informative. 🙁

&nbsp;