---
id: 195
title: 'paypal-wujinggou.com &#8211; DOM Cross-Site Scripting'
date: 2019-02-26T19:18:16+00:00
author: admin
layout: post
guid: https://syzhack.com/blog/?p=195
permalink: /index.php/2019/02/26/paypal-wujinggou-com-dom-cross-site-scripting/
nullpoint_basic_post_layer_select:
  - 1-col
nullpoint_post_allow_breadcrumbs:
  - 'no'
nullpoint_post_nav:
  - 'no'
categories:
  - bug bounty
---
<img class="wp-image-79 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Paypal-Logo-2015.png" alt="" width="413" height="118" />

Hello guys!

Today, when I was looking in my &#8220;sent&#8221; directory of my old Yahoo Mail account I found some interesting and I think it&#8217;s a good idea to share it. At Jan 22 2014, I found and reported a DOM Cross-Site Scripting vulnerability in paypal-wujinggou.com. Actually the domain it&#8217;s unavailable.

Note: I was 16 years old. I&#8217;m aware that at that time my English was not great, but anyway, the intention counts. 😁

I leave you a screen with my report.

<img class="alignnone size-full wp-image-196" src="https://syzhack.com/blog/wp-content/uploads/2019/02/paypalold.png" alt="" width="1604" height="792" /> 

I don&#8217;t have replies from the security team because at that moment PayPal worked with eBay.  For those who know: https://keys.ebay.com/b/b.e?r=example@email.com&n=zo7nStZ/25L8nbU5kZr0bA==

I don&#8217;t remember the timeline. I think the bug was repaired in ~ 2 weeks and I got $150 and Hall of Fame.

✌