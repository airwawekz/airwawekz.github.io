---
id: 75
title: mail.google.com – Mobile APP (iOS 10.3.3) – Stored Cross-Site Scripting – $5,000 Bounty Awarded
date: 2018-12-08T00:17:39+00:00
author: admin
layout: post
guid: https://syzhack.com/blog/?p=75
permalink: /index.php/2018/12/08/mail-google-com-mobile-app-ios-stored-cross-site-scripting/
nullpoint_basic_post_layer_select:
  - 1-col
nullpoint_post_nav:
  - 'no'
nullpoint_post_allow_breadcrumbs:
  - 'no'
categories:
  - bug bounty
tags:
  - gmail vulnerability
  - gmail XSS
  - google bug bounty
  - google reward
  - Google Stored Cross-Site Scripting
  - google vulnerability
  - Google XSS
---
###<img class="wp-image-76 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Googlelogo.png" alt="" width="194" height="66" /> 

### #Vulnerability type:

Stored Cross-Site Scripting

### #Author:

Măgherușan Ovidiu Teodor  
&#8212;-

### #Proof of concept:<figure id="9d65" class="graf graf--figure graf-after--p"> 

<div class="aspectRatioPlaceholder is-locked">
  <p>
  </p>
  
  <h3 id="a384" class="graf graf--h3 graf-after--p">
    #Vendor response:
  </h3>
  
  <p id="634a" class="graf graf--p graf-after--h3">
    Google provides standardized rewards for most security bugs, as described on the page for it&#8217;s <a class="markup--anchor markup--p-anchor" href="https://www.google.com/about/appsecurity/reward-program/index.html#rewards" target="_blank" rel="nofollow noopener" data-href="https://www.google.com/about/appsecurity/reward-program/index.html#rewards">vulnerability reward program</a>. In our case, a proper XSS on the mail.google.com (Mobile APP) domain will usually trigger a $5,000 bounty.
  </p>
  
  <p id="0fc4" class="graf graf--p graf-after--p">
    8 August 2017, 17:48 — I fill in the <a class="markup--anchor markup--p-anchor" href="https://www.google.com/appserve/security-bugs/new" target="_blank" rel="nofollow noopener" data-href="https://www.google.com/appserve/security-bugs/new">report form</a>.<br /> 9 August 2017, 01:06 — My report is triaged, already!<br /> 10 August 2017, 13:50 — My report is validated, bug filed.<br /> 11 August 2017, ? — Well, this is fixed.<br /> 16 August 2017, 13:50 —<img class="size-full wp-image-82 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Screenshot_3.png" alt="" width="634" height="772" />
  </p>
  
  <p>
    &nbsp;
  </p>
</div></figure> 

&nbsp;

### #Hall of Fame:

https://bughunter.withgoogle.com/profile/9c53933c-4d4e-4989-b029-89e2c10290c8