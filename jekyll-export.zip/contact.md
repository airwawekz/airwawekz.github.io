---
id: 7
title: Contact
date: 2018-10-13T10:43:48+00:00
author: admin
layout: page
guid: https://syzhack.com/blog/?page_id=7
nullpoint_basic_post_layer_select:
  - 1-col
nullpoint_post_transparent_header:
  - 'no'
nullpoint_post_allow_breadcrumbs:
  - 'no'
nullpoint_top_padding:
  - ""
nullpoint_bottom_padding:
  - ""
---
<p style="text-align: center;">
  <img class="wp-image-93 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/gmail.png" alt="" width="40" height="40" /><strong><a href="mailto:0xstrait@gmail.com?Subject=" target="_top">0xstrait@gmail.com</a></strong>
</p>

&nbsp;

<img class="wp-image-92 aligncenter" src="https://syzhack.com/blog/wp-content/uploads/2018/12/Twitter_bird_logo_2012.svg_.png" alt="" width="40" height="32" /> 

<a class="twitter-timeline" data-width="1200" data-height="1000" data-dnt="true" href="https://twitter.com/0xstrait1337?ref_src=twsrc%5Etfw">Tweets by 0xstrait1337</a>

&nbsp;